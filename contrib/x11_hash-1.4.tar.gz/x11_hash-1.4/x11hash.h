#ifndef X11HASH_H
#define X11HASH_H

#ifdef __cplusplus
extern "C" {
#endif

void x11_hash(const char* input, char* output);

#ifdef __cplusplus
}
#endif

#endif
