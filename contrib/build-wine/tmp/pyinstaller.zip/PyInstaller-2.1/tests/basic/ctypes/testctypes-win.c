int __declspec(dllexport) dummy(int arg)
{
    return arg;
}
